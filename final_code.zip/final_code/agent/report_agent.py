import base64
from agent.initiate_llm import image_llm, IMAGE_MODEL

def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")


analysis_prompt = """
Given the context about the image and/or data, provide a detailed analysis, insight and future predictions (if applicable) about the plot image.
Only give a natural langauge paragraph response about the insights dran from the trends and pattern in the plot image and *DO NOT* mention anything about the technical details of the plot image.
Here is the context:
"""

def get_image_analysis(image_path, context) -> str:
    base64_image = encode_image(image_path)
    completion = image_llm.chat.completions.create(
        model=IMAGE_MODEL,
        messages=[
            {
                "role": "user",
                "content": [
                    { "type": "text", "text": analysis_prompt + context },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{base64_image}",
                        },
                    },
                ],
            }
        ],
    )

    return completion.choices[0].message.content


# image_path = "/Users/mehulmathur/532_final_project/static/images/viz_0b393de515ca49aa82500d9ca9be3a10.png"

# base64_image = encode_image(image_path)

# completion = client.chat.completions.create(
#     model="gpt-4.1",
#     messages=[
#         {
#             "role": "user",
#             "content": [
#                 { "type": "text", "text": "what's in this image?" },
#                 {
#                     "type": "image_url",
#                     "image_url": {
#                         "url": f"data:image/jpeg;base64,{base64_image}",
#                     },
#                 },
#             ],
#         }
#     ],
# )

# print(completion.choices[0].message.content)

